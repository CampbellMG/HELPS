CREATE FUNCTION round(numeric) RETURNS numeric
  IMMUTABLE
  STRICT
  PARALLEL SAFE
  COST 1
  LANGUAGE SQL
AS
$$
select pg_catalog.round($1,0)
$$;

COMMENT ON FUNCTION round(numeric) IS 'value rounded to ''scale'' of zero';

ALTER FUNCTION round(numeric) OWNER TO postgres;

