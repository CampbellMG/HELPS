CREATE FUNCTION "overlaps"(timestamp without time zone, timestamp without time zone, timestamp without time zone, interval) RETURNS boolean
  IMMUTABLE
  PARALLEL SAFE
  COST 1
  LANGUAGE SQL
AS
$$
select ($1, $2) overlaps ($3, ($3 + $4))
$$;

COMMENT ON FUNCTION "overlaps"(timestamp, timestamp, timestamp, interval) IS 'intervals overlap?';

ALTER FUNCTION "overlaps"(timestamp, timestamp, timestamp, interval) OWNER TO postgres;

