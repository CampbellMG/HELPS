CREATE FUNCTION "overlaps"(timestamp with time zone, timestamp with time zone, timestamp with time zone, interval) RETURNS boolean
  STABLE
  PARALLEL SAFE
  COST 1
  LANGUAGE SQL
AS
$$
select ($1, $2) overlaps ($3, ($3 + $4))
$$;

COMMENT ON FUNCTION "overlaps"(timestamp WITH TIME ZONE, timestamp WITH TIME ZONE, timestamp WITH TIME ZONE, interval) IS 'intervals overlap?';

ALTER FUNCTION "overlaps"(timestamp WITH TIME ZONE, timestamp WITH TIME ZONE, timestamp WITH TIME ZONE, interval) OWNER TO postgres;

